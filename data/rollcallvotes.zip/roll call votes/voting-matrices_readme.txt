Citations:

In using this data, please be sure to cite 

   (1) http://voteview.com/

   (2) "Party polarization in Congress: a network science approach,"
       A. Waugh, L. Pei, J. H. Fowler, P. J. Mucha and M. A. Porter,
       arXiv:0907.3509.


Newly reprocessed data:

Raw data taken from voteview (voteview.tar.gz or 1-108, and get final 109 and 110 from voteview site).

All Votes:

collectrollcalls.m generates rollcall.mat, with the single struct variable RollCall of unique legislator IDs (mostly ICPSR), and cell numbers corresponding to data from the House of Representatives and the Senate. For example, RollCall.HID{85} is the ID numbers in the 85th House roll call, with RollCall.Hstring{85} the corresponding full identifier string as it appears in voteview, and RollCall.HA{85} the generated matrix of voting similarities tabulated for each legislator pair as the number of times they voted the same way (i.e., the sum of times they both voted yea plus the number of times they both voted nay) divided by the number of times that they both voted.


Removing "Nearly Unanimous" Votes:

collectrollcalls97.m generates rollcall97.mat, with the single struct variable RollCall97. Same format as above. Only difference is that votes where greater than 97% of the votes cast were yeas were removed, per the description in the recent Waugh et al. paper (though I'm not fully confident that was the actual cutoff used; it might have been at 97% after rounding or some such, so the actual threshold there might be something like 97.5%?).

collectrollcalls97a.m generates rollcall97a.mat, with the added information of party IDs captured and stored.


Some issues with ID numbers:

Pay close attention to the information on the ICPSR ID Numbers Page
(http://voteview.com/icpsr.htm). It seems that the vast majority
(>200) of party switches in the data do not invoke changes in the ID
number. However, there are a number of cases where the ID changes by
some multiple of 10000. These are the only cases explored so far,
uncovering 6 cases in the Senate data:

   Jeffords 14240 -> 94240 during 107th Senate
   Shelby 14659 -> 94659 between 103rd and 104th
   Campbell 15407 -> 95407 during 104th Senate
   Morse 96738 -> 6738 between 82nd and 83rd
   Thurmond 99369 -> 9369 between 88th and 89th
   Carper 40100 -> 15015 between 107th and 108th

We have only identified these cases; we have not rectified them. Note
that the switches during Congresses means these individuals actually
appear as two distinct legislators in the data of those terms. In
addition to the above, one will want to check both Lieberman & Specter
if looking at data from the 111th & 112th Senates. Similar issues
presumably appear if looking at IDs in the House. 

One could consider a brute-force name/state matching procedure to see
if it turns up anything else; but do not trust that procedure on its
own to link identities since there are many instances of a seat
staying in the same family. As examples, looking only at the Senate
since the 90th Congress, this list includes Bayh, Bennett, Chafee,
Dodd, Gore, Murkowski and Pryor.
