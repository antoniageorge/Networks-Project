clear RollCall

%First pass just to get list of legislator IDs
IDs=char('');
for ic=1:110,
    icstr=int2str(ic);
    if ic<10, icstr=['0',icstr]; end
    H=char(textread(['voteview/hou',icstr,'kh.ord'],'%s','delimiter','\n'));
    if strfind(H(1,:),'USA'), H=H(2:end,:); end
    S=char(textread(['voteview/sen',icstr,'kh.ord'],'%s','delimiter','\n'));
    if strfind(S(1,:),'USA'), S=S(2:end,:); end
    IDs=[IDs;H(:,4:10);S(:,4:10)];
end
RollCall.IDs=unique(IDs,'rows');

%Now re-run through individual Congresses to build adjacency slices
for ic=1:110,
    icstr=int2str(ic)
    if ic<10, icstr=['0',icstr]; end

    %Process House Roll Call:
    H=char(textread(['voteview/hou',icstr,'kh.ord'],'%s','delimiter','\n'));
    while strfind(H(1,:),'USA'), H=H(2:end,:); end
    IDindx=min(findstr(int2str(ic),H(1,:)))+length(int2str(ic))+[0:4];
    Partyindx=max(IDindx)+(12:15);
    HouseID=str2num(H(:,IDindx));
    PartyID=str2num(H(:,Partyindx));
    endstring=max(regexp(H(1,:),'\D'));
    HouseString=H(:,1:endstring);
    votestr=H(:,endstring+1:end);
    votes=zeros(size(votestr));
    for row=1:size(votestr,1),
        votes(row,:)=str2num(votestr(row,:)')';
    end
    votes(votes==2)=1;
    votes(votes==3)=1;
    votes(votes==4)=-1;
    votes(votes==5)=-1;
    votes(votes==6)=-1;
    votes(votes==7)=0;
    votes(votes==8)=0;
    votes(votes==9)=0;
    yeas=sum(votes>0);
    tots=sum(abs(votes));
    votes=votes(:,yeas./tots<=.97); %Remove "nearly unanimous" votes
    C=abs(votes)*abs(votes');
    ind=(diag(C)>0); %Now remove legislators who didn't vote
    HouseID=HouseID(ind,:);
    PartyID=PartyID(ind,:);
    HouseString=HouseString(ind,:);
    votes=votes(ind,:);
    C=abs(votes)*abs(votes');
    A=(votes*votes'+C)/2./C;
    A(C==0)=0;
    RollCall.HID{ic}=HouseID;
    RollCall.HP{ic}=PartyID;    
    RollCall.Hstring{ic}=HouseString;
    RollCall.HA{ic}=A-diag(diag(A));    
    
    %Process Senate Roll Call:
    H=char(textread(['voteview/sen',icstr,'kh.ord'],'%s','delimiter','\n'));
    while strfind(H(1,:),'USA'), H=H(2:end,:); end
    IDindx=min(findstr(int2str(ic),H(1,:)))+length(int2str(ic))+[0:4];
    Partyindx=max(IDindx)+(12:15);
    HouseID=str2num(H(:,IDindx));
    PartyID=str2num(H(:,Partyindx));
    endstring=max(regexp(H(1,:),'\D'));
    HouseString=H(:,1:endstring);
    votestr=H(:,endstring+1:end);
    votes=zeros(size(votestr));
    for row=1:size(votestr,1),
        votes(row,:)=str2num(votestr(row,:)')';
    end
    votes(votes==2)=1;
    votes(votes==3)=1;
    votes(votes==4)=-1;
    votes(votes==5)=-1;
    votes(votes==6)=-1;
    votes(votes==7)=0;
    votes(votes==8)=0;
    votes(votes==9)=0;
    yeas=sum(votes>0);
    tots=sum(abs(votes));
    votes=votes(:,yeas./tots<=.97); %Remove "nearly unanimous" votes
    C=abs(votes)*abs(votes');
    ind=(diag(C)>0); %Now remove legislators who didn't vote
    HouseID=HouseID(ind,:);
    PartyID=PartyID(ind,:);
    HouseString=HouseString(ind,:);
    votes=votes(ind,:);
    C=abs(votes)*abs(votes');
    A=(votes*votes'+C)/2./C;
    A(C==0)=0;
    RollCall.SID{ic}=HouseID;
    RollCall.SP{ic}=PartyID;
    RollCall.Sstring{ic}=HouseString;
    RollCall.SA{ic}=A-diag(diag(A));    

end

RollCall97=RollCall;
save rollcall97a.mat RollCall97
